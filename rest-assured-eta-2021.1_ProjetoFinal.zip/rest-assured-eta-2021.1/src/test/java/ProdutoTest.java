import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import models.Produtos;
import models.User;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static requests.LoginEnpoints.postLoginRequest;
import static requests.ProdutosEndpoints.postProdutoRequest;
import static requests.UserEndpoints.deleteUserRequest;
import static requests.UserEndpoints.postUserRequest;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static requests.ProdutosEndpoints.*;
import java.util.List;

public class ProdutoTest extends TestBase{

    private User adminUser;
    private User noAdminUser;
    private Produtos newProduct1;
    private Produtos errorProduct2;
    private Produtos ActualProc;

    @BeforeClass
    public void generateTestData() {
        //Usuários
        adminUser = new User("Jose", "jose001@gmail.com", "1234", "true");
        noAdminUser = new User("Pedro", "pedro0001@gmail.com", "123456", "false");
        postUserRequest(SPEC, adminUser);
        postUserRequest(SPEC, noAdminUser);
        postLoginRequest(SPEC, adminUser);
        postLoginRequest(SPEC, noAdminUser);

        //Produtos
        newProduct1 = new Produtos("Lenovo Thinkpad", 2900, "Notebook", 190);
        errorProduct2 = new Produtos("Acer A315-56-356Y", 3500, "Notebook", 560);
        ActualProc = new Produtos("Logitech MX Vertical", 470, "Mouse", 381);
    }

    @Test(priority = 0)
    public void shouldReturnSuccessMessageAndStatusCode201(){
        SPEC.header("Authorization", adminUser.getAuthorization_id());

        Response registerProductResponse = postProdutoRequest(SPEC, newProduct1, adminUser);
        registerProductResponse.
                then().
                assertThat().
                statusCode(201).
                body("message", Matchers.equalTo("Cadastro realizado com sucesso")).
                body("_id", Matchers.notNullValue());

        FilterableRequestSpecification filterableRequestSpecification = (FilterableRequestSpecification) SPEC;
        filterableRequestSpecification.removeHeader("Authorization");
    }

    @Test(priority = 1)
    public void shouldReturnErrorMessageAndStatusCode403(){
        SPEC.header("Authorization", noAdminUser.getAuthorization_id());

        Response registerProductResponse = postProdutoRequest(SPEC, errorProduct2, noAdminUser);
        registerProductResponse.
                then().
                assertThat().
                statusCode(403).
                body("message", Matchers.equalTo("Rota exclusiva para administradores"));

        FilterableRequestSpecification filterableRequestSpecification = (FilterableRequestSpecification) SPEC;
        filterableRequestSpecification.removeHeader("Authorization");
    }

    @Test(priority = 2)
    public void shouldReturnErrorMessageAndStatusCode401(){
        Response registerProductResponse = postProdutoRequest(SPEC, errorProduct2, noAdminUser);
        registerProductResponse.
                then().
                assertThat().
                statusCode(401).
                body("message", Matchers.equalTo("Token de acesso ausente, inválido, expirado ou usuário do token não existe mais"));
    }

    @Test(priority = 3)
    public void shouldReturnErrorMessageAndStatusCode400(){
        SPEC.header("Authorization", adminUser.getAuthorization_id());

        Response registerProductResponse = postProdutoRequest(SPEC, ActualProc, adminUser);
        registerProductResponse.
                then().
                assertThat().
                statusCode(400).
                body("message", Matchers.equalTo("Já existe produto com esse nome"));

        FilterableRequestSpecification filterableRequestSpecification = (FilterableRequestSpecification) SPEC;
        filterableRequestSpecification.removeHeader("Authorization");
    }

    @Test(priority = 4)
    public void shouldReturnSuccessDuringRequestProductsAndStatusCode200(){
        Response getProdutosResponse = getProdutoRequest(SPEC);
        getProdutosResponse.
                then().
                assertThat().
                statusCode(200).
                body("quantidade", equalTo(3)).
                body("quantidade", instanceOf(Integer.class)).
                body("produtos", instanceOf(List.class));
    }

    @AfterClass
    public void removeTestData() {
        deleteProductRequest(SPEC, newProduct1, adminUser);
        deleteUserRequest(SPEC, adminUser);
        deleteUserRequest(SPEC, noAdminUser);
    }
}