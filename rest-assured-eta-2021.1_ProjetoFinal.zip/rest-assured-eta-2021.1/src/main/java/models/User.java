package models;

import com.google.gson.JsonObject;

public class User {

    public String nome;
    public String email;
    public String password;
    public String _id;
    public String administrador;
    private String authorization_id;

    public User(String nome, String email, String password, String administrador) {
        this.nome = nome;
        this.email = email;
        this.password = password;
        this.administrador = administrador;
    }

    public void setUserId(String userId){
        this._id = userId;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getAdministrador() {
        return administrador;
    }

    public String getId_() {
        return _id;
    }

    public void setId_(String id_) {
        this._id = _id;
    }

    public String getAuthorization_id() {
        return authorization_id;
    }

    public void setAuthorization_id(String authorization_id) {
        this.authorization_id = authorization_id;
    }

    public String getUserCredentials(){
        JsonObject userJsonRepresentation = new JsonObject();
        userJsonRepresentation.addProperty("email", this.email);
        userJsonRepresentation.addProperty("password", this.password);
        return userJsonRepresentation.toString();
    }
}