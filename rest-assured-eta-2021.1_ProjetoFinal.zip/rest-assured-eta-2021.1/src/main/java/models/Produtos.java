package models;

import com.google.gson.JsonObject;

public class Produtos {

    private String nome;
    private Integer preco;
    private String descricao;
    private Integer quantidade;
    private String _id;
    private String id_user;

    public Produtos(String nome, int preco, String descricao, int quantidade) {
        this.nome = nome;
        this.preco = preco;
        this.descricao = descricao;
        this.quantidade = quantidade;
    }

    public String getNome() {
        return nome;
    }

    public int getPreco() {
        return preco;
    }

    public String getDescricao() {
        return descricao;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getId_user() {
        return id_user;
    }

    public void setId_user(String id_user) {
        this.id_user = id_user;
    }

    public String getJsonProduto(){
        JsonObject userJsonRepresentation = new JsonObject();
        userJsonRepresentation.addProperty("nome", this.nome);
        userJsonRepresentation.addProperty("preco", this.preco);
        userJsonRepresentation.addProperty("descricao", this.descricao);
        userJsonRepresentation.addProperty("quantidade", this.quantidade);
        return userJsonRepresentation.toString();
    }
}