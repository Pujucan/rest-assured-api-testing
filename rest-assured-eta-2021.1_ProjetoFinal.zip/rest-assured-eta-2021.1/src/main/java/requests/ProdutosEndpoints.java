package requests;

import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import models.Produtos;
import models.User;
import static io.restassured.RestAssured.given;

public class ProdutosEndpoints extends RequestBase{

    public static Response getProdutoRequest(RequestSpecification spec){
        Response getProdutoResponse =
                given().
                        spec(spec).
                        when().
                        get("/produtos");

        return getProdutoResponse;
    }

    public static Response postProdutoRequest(RequestSpecification spec, Produtos prod, User user){

        Response postProdutoRequest =
                given().
                        spec(spec).
                        header("Content-Type", "application/json").
                        and().
                        body(prod.getJsonProduto()).
                        when().
                        post("/produtos");

        prod.set_id(getValueFromResponse(postProdutoRequest, "_id"));
        prod.setId_user(user.getId_());
        return postProdutoRequest;
    }

    public static Response deleteProductRequest(RequestSpecification spec, Produtos prod, User user){
        spec.header("Authorization", user.getAuthorization_id());

        Response deleteProdutoResponse =
                given().
                        spec(spec).
                        pathParam("id_", prod.get_id()).
                        when().
                        delete("/produtos/{id_}");

        FilterableRequestSpecification filterableRequestSpecification = (FilterableRequestSpecification) spec;
        filterableRequestSpecification.removeHeader("Authorization");

        return deleteProdutoResponse;
    }
}